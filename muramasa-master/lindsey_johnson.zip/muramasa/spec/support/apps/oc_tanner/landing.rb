class OCTLandingPage < AutomationFramework::Utilities
  include Capybara::DSL
  include Header


end